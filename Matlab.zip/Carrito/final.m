% Equipo 2
% Melissa Robles García A01637961
% Michelle Borjon-Arriola A01638100
% Héctor Morales Villalobos A01637304
% Nathalia Belén Muñoz Durán A01636143
% José David Padilla Márquez A01746712
% Johann Michael Acaro Andrade A01636269


close all
clc

%% Generación del mapa
% 
% if isempty(BinaryMap) == 1
%     BinaryMap = makemap(900);
% end 
% 
% figure()
map = binaryOccupancyMap(rot90(transpose(BinaryMap)),890/9);
% show(map);

%% Generación de PRM
% nodes = 250;
% planner = mobileRobotPRM(map, nodes);
% figure()
% show(planner)

%% Generación de trayectoria
% startLocation = [7 0.5];
% endLocation = [3 8.5];
% 
% path = findpath(planner, startLocation, endLocation);
% figure()
% show(planner)

%% Definición de pose inicial
x = path(1,1);
y = path(1,2);
theta = 0;

%% Definición de pose final deseada
x1 = path(2,1);
y1 = path(2,2);

%% Definición del paso
delta_t = 0.05;

%% Definición de coeficientes
ka = 3;

i = 1;

d = 0.1;

%% Cálculo de parámetros 
n = length(path);


%% Modelación del movimiento
for k=1:(n-1)
    x1 = path(k+1,1);
    y1 = path(k+1,2);
    
    dx = x1 - x;
    dy = y1 - y;

    dist = sqrt(dx^2 + dy^2);
    theta_d = atan2(dy,dx);

    alpha = theta_d - theta;
    
    while dist>0.01
        v = 0.75;
        omega = ka*alpha;
        
%         vr = v + d*omega;
%         vl = v - d*omega;
        
%         pwm1 = round(59.393*vr);
%         pwm2 = round(49.48*vl);
%         
%         if pwm1>255
%             pwm1 = 255;
%         end
%         
%         if pwm2>255
%             pwm2 = 255;
%         end
%         
%         if abs(pwm1)<35 && abs(pwm1)>=0
%             if pwm1 < 0
%                 dir_1 = 1;
%             end 
%             pwm1 = 35;
%         elseif pwm1<0
%             pwm1 = abs(pwm1);
%             dir_1 = 1;
%         else 
%             dir_1 = 0;
%         end
%          
%         if pwm2<35 && pwm2>=0
%             pwm2 = 35;
%         end
%         
%         if pwm2<0
%             pwm2 = abs(pwm2);
%             dir_2 = 0;
%         else 
%             dir_2 = 1;
%         end
        
%         pwm1 
%         dir_1
%         pwm2
%         dir_2
        
%         write(bt, [0, dir_1, pwm1])
%         write(bt, [1, dir_2, pwm2])

        vx = v*cos(theta);
        vy = v*sin(theta);

        x = x + vx*delta_t;
        y = y + vy*delta_t;
        theta = theta + omega*delta_t;

        figure(1)
        scatter(x,y,'.r')

        if i==1 
            hold
            show(map);
            i = 0;
        end 

        dx = x1 - x;
        dy = y1 - y;

        dist = sqrt(dx^2 + dy^2);
        theta_d = atan2(dy,dx);

        alpha = theta_d - theta;
        
%         pause(0.5)
    end
end 